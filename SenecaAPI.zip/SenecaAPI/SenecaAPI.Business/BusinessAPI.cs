﻿using RestSharp;
using SenecaAPI.Entities;
using System;
using System.Threading.Tasks;

namespace SenecaAPI.Business
{
    public class BusinessAPI : IBusinessAPI 
    {
        /// <summary>
        /// Gets response from GEO API
        /// </summary>
        /// <param name="ipAddress"></param>
        /// <returns></returns>
        public  string GetGeoResult(string ipAddress)
        {
            string geoipURL = "https://freegeoip.app/json/{0}";
            geoipURL = string.Format(geoipURL, ipAddress);

            IRestResponse restResponse = null;
            RestClient restClient = new RestClient(geoipURL);
            IRestRequest request = new RestRequest(Method.GET);

            Task<IRestResponse> t = restClient.ExecuteAsync(request);
            t.Wait();
            restResponse= t.GetAwaiter().GetResult();

            return restResponse.Content;
        }

      
        /// <summary>
        /// Gets response from RDAP API
        /// </summary>
        /// <param name="ipAddress"></param>
        /// <returns></returns>
        public string GetRDAPResult(string ipAddress)
        {
            string rdapipURL = "https://rdap.arin.net/registry/ip/{0}";
            rdapipURL = string.Format(rdapipURL, ipAddress);

            IRestResponse restResponse = null;
            RestClient restClient = new RestClient(rdapipURL);
            IRestRequest request = new RestRequest(Method.GET);

            Task<IRestResponse> t = restClient.ExecuteAsync(request);
            t.Wait();
            restResponse = t.GetAwaiter().GetResult();

            return restResponse.Content;

        }
    }
}
