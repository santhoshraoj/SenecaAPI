﻿using RestSharp;
using SenecaAPI.Entities;
using System;
using System.Threading.Tasks;

namespace SenecaAPI.Business
{
    public interface  IBusinessAPI
    {
        public string GetGeoResult(string ipAddress);
        public string GetRDAPResult(string ipAddress);

    }
}
