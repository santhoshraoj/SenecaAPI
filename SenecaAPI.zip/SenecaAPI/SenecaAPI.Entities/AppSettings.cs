﻿using System;

namespace SenecaAPI.Entities
{
    public class AppSettings
    {
        //Token releated
        public Security Security { get; set; }
        public KimbleTokenRequest KimbleTokenRequest { get; set; }
        public KimbleTokenResponse KimbleTokenResponse { get; set; }
        // public KimbleRequestRefreshToken KimbleRequestRefreshToken { get; set; }


        public MingleTokenRequest MingleTokenRequest { get; set; }
        public MingleTokenResponse MingleTokenResponse { get; set; }

        public string SwaggerEndpoint { get; set; }
        public string TokenUrl { get; set; }

        //connection string
        public ConnectionStrings ConnectionStrings { get; set; }

        public AppSettings StatusRequest { get; set; }

        public string LifeTime { get; set; } //life time in minutes 24 hours= 1440 min

    }

    public class Security
    {
        public Jwt Jwt { get; set; }
    }

    public class Jwt
    {
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string Audience { get; set; }
        public string Authority { get; set; }
    }




    public class ConnectionStrings
    {
        public string CLM { get; set; }
        public string Clarity { get; set; }
        public string ApprovalMatrix { get; set; }
        public string Polaris { get; set; }
        public string InforServices { get; set; }
    }



    public class KimbleTokenRequest
    {
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string AuthURL { get; set; }
        public string AccessTokenURL { get; set; }
        public string Scope { get; set; }
        public string RedirectURI { get; set; }
        public string AuthCode { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string RefreshToken { get; set; }
        public string AccountToken { get; set; }
    }


    public class KimbleTokenResponse
    {
        public string access_token { get; set; }
        public string token_type { get; set; }
        public string refresh_token { get; set; }
        public string scope { get; set; }
        public string signature { get; set; }
        public string id_token { get; set; }
        public string instance_url { get; set; }
        public string id { get; set; }
        public string issued_at { get; set; }
        public string expires_at { get; set; }
        public string AccountToken { get; set; } //user token it will be differ for each account login
        public string LifeTime { get; set; }
    }


    //public class KimbleRequestRefreshToken
    //{
    //    public string ExpiresIn { get; set; }
    //    public string RefreshToken { get; set; }
    //    public string ExpireAt { get; set; }
    //}


    public class MingleTokenRequest
    {
        public string TokenUrl { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        public string CompassQuery { get; set; }
    }


    public class MingleTokenResponse
    {
        public string access_token { get; set; }
        public string refresh_token { get; set; }
        public string token_type { get; set; }
        public string expires_in { get; set; }
    }

    public class StatusRequest
    {
        public string status { get; set; }
        public string location { get; set; }
        public string queryId { get; set; }
    }

    public enum CheckStatusType
    {
        RUNNING,
        FINISHED,
        RanToCompletion,
        TRANSFORMING,
        FAILED
    }
}
