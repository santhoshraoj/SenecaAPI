using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;
using SenecaAPI.Business;
using SenecaAPI.ConfigureApp;
using SenecaAPI.Entities;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SenecaAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container
        public void ConfigureServices(IServiceCollection services)
        {
            //services.add(interfacename, classname)
            //services.Add(new ServiceDescriptor(typeof(ILog), new MyConsoleLogger())); // singleton 
            //services.Add(new ServiceDescriptor(typeof(ILog), typeof(MyConsoleLogger), ServiceLifetime.Transient));// Transient 
            //services.Add(new ServiceDescriptor(typeof(ILog), typeof(MyConsoleLogger), ServiceLifetime.Scoped)); // Scoped
            //Singleton: IoC container will create and share a single instance of a service throughout the application's lifetime.
            //Transient: The IoC container will create a new instance of the specified service type every time you ask for it.
            //Scoped: IoC container will create an instance of the specified service type once per request and will be shared in a single request.

            //services.AddControllers();

            //services.AddTransient<ITestDatabase, TestDatabase>();
            services.AddTokenAuthentication(Configuration);
            services.Configure<AppSettings>(Configuration);
            services.AddLogging();
            services.AddTransient<IConfigureOptions<SwaggerGenOptions>, ConfigureSwaggerGenOptions>();
            services.AddScoped(sp => sp.GetRequiredService<IOptionsSnapshot<AppSettings>>().Value);
            services.AddControllers();
            services.AddAuthentication(options =>
            {
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            });

            services.AddHttpClient();
            services.AddSwaggerGen();
            services.AddScoped<IBusinessAPI, BusinessAPI>();
            //services.AddControllers().AddXmlDataContractSerializerFormatters();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {

            var appSettings = Configuration.Get<AppSettings>();
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app
            .UseSwagger()
            .UseSwaggerUI(setup =>
            {
                string swaggerJsonBasePath = string.IsNullOrWhiteSpace(setup.RoutePrefix) ? "." : "..";
                setup.SwaggerEndpoint($"{swaggerJsonBasePath}/swagger/v1/swagger.json", "Version 1.0");
                //setup.SwaggerEndpoint("/swagger/v1/swagger.json", "Version 1.0");
                setup.OAuthClientId(appSettings.Security.Jwt.ClientId);
                setup.OAuthClientSecret(appSettings.Security.Jwt.ClientSecret);
                setup.OAuthAppName("Infor Services Softrax Api");
                setup.OAuthScopeSeparator(" ");
                setup.OAuthUsePkce();
            });

            app.UseAuthentication();
            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseAuthorization();
            app.UseExceptionHandler("/Error");
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapGet("/", async context =>
                {
                    //Welcome to running ASP.NET Core on AWS Lambda
                    await context.Response.WriteAsync("Welcome to running Infor Services Softrax Api, running on AWS Lambda");
                });
            });
        }
    }
}
