﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RestSharp;
using System.Net.Http;
using SenecaAPI.Entities;
using Newtonsoft.Json;
using SenecaAPI.Business;
using System.Text;
using Microsoft.AspNetCore.Diagnostics;

namespace SenecaAPI.Controllers
{
    [ApiController]
    //[Route("[Errorcontroller]")]
    public class ErrorController : ControllerBase
    {
        private readonly ILogger<ErrorController> logger;

        public ErrorController(ILogger<ErrorController> logger)
        {
            this.logger = logger;
        }
        [Route("Error")]
        public void HandleErrors()
        {
            var exceptionDetails = HttpContext.Features.Get<IExceptionHandlerPathFeature>();
            logger.LogError($"The path {exceptionDetails.Path} threw an exception " + $"{exceptionDetails.Error}");

        }


    }
}
