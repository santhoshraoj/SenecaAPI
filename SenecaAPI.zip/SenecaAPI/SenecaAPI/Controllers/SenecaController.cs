﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RestSharp;
using System.Net.Http;
using SenecaAPI.Entities;
using Newtonsoft.Json;
using SenecaAPI.Business;
using System.Text;

namespace SenecaAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class SenecaController : ControllerBase
    {
        
        private readonly IBusinessAPI businessAPI;

        public SenecaController(ILogger<SenecaController> logger,IBusinessAPI businessAPI)
        {
            this.businessAPI = businessAPI;
        }

        /// <summary>
        /// Gets responses from multiple APIS and returns one consolidated response
        /// </summary>
        /// <param name="ipAddress"></param>
        /// <returns></returns>
        [HttpGet]
        public string GetDetailsUsingIP(string ipAddress)
        {
            StringBuilder result = new StringBuilder();
            var geoResult = businessAPI.GetGeoResult(ipAddress);
            var rdapResult = businessAPI.GetRDAPResult(ipAddress);

            result.Append(geoResult.ToString());
            result.Append(rdapResult.ToString());

            return result.ToString();
        }

      
    }
}
